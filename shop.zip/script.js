const products = [
  { id: 1, name: 'Телефон', price: 5000, quantity: 5 },
  { id: 2, name: 'Навушники', price: 1200, quantity: 10 },
  { id: 3, name: 'Ноутбук', price: 15000, quantity: 3 }
];

const cart = {};

function renderProducts() {
  const productsDiv = document.getElementById('products');
  productsDiv.innerHTML = '';

  products.forEach(product => {
    const productDiv = document.createElement('div');
    productDiv.className = 'product';
    productDiv.innerHTML = `
      <h3>${product.name}</h3>
      <p>Ціна: ${product.price} грн</p>
      <p>Залишилось: ${product.quantity}</p>
      <button onclick="addToCart(${product.id})" ${product.quantity === 0 ? 'disabled' : ''}>Додати в корзину</button>
    `;
    productsDiv.appendChild(productDiv);
  });
}

function renderCart() {
  const cartDiv = document.getElementById('cart');
  cartDiv.innerHTML = '';

  let total = 0;

  for (const productId in cart) {
    const item = cart[productId];
    const itemTotal = item.price * item.quantity;
    total += itemTotal;

    const itemDiv = document.createElement('div');
    itemDiv.className = 'cart-item';
    itemDiv.innerHTML = `
      <h4>${item.name}</h4>
      <p>Кількість: ${item.quantity}</p>
      <p>Сума: ${itemTotal} грн</p>
    `;
    cartDiv.appendChild(itemDiv);
  }

  const totalDiv = document.createElement('div');
  totalDiv.innerHTML = `<h3>Загальна сума: ${total} грн</h3>`;
  cartDiv.appendChild(totalDiv);
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  if (!product || product.quantity === 0) return;

  product.quantity--;

  if (cart[id]) {
    cart[id].quantity++;
  } else {
    cart[id] = {
      name: product.name,
      price: product.price,
      quantity: 1
    };
  }

  renderProducts();
  renderCart();
}

renderProducts();
renderCart();
